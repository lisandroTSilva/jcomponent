DROP TABLE IF EXISTS `#__eventos`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_eventos.%');