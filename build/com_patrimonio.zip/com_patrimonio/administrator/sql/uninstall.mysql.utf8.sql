DROP TABLE IF EXISTS `#__patrimonio_patrimonio`;
